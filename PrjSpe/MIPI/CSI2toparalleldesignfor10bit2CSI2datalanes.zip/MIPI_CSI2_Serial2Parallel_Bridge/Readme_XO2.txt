CSI2 XO2 Sensor Bridge Design Readme

Diamond project file:   MIPI_CSI2_Serial2Parallel_Bridge.ldf
Top level design file:  MIPI_CSI2_Serial2Parallel_Bridge.v
                        MIPI_CSI2_Serial2Parallel_Bridge_Demo.v   <= Demo to be use with Lattice Dual Sensor Interface Board and Lattice CSI2 to Parallel Board
Design pinout:          MIPI_CSI2_Serial2Parallel_Bridge.lpf      <= Can also be obtained in RD1120 at latticesemi.com
                        MIPI_CSI2_Serial2Parallel_Bridge_Demo.lpf <= Demo to be use with Lattice Dual Sensor Interface Board and Lattice CSI2 to Parallel Board
Bitstreams:             \bitstream\*.jed
Timing Report:          MIPI_CSI2_Serial2Parallel_Bridge.twr (only availible after synthesizing design and checking "Place & Route Trace" in Lattice Diamond Software

